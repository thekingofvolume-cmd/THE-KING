package com.king
object AppConfig {
    const val GATEWAY_BASE_URL = "https://api.the-king.trade"
    const val MODEL_MIN_CONF = 0.58f
    const val ENSEMBLE_MIN_CONF = 0.62f
}
