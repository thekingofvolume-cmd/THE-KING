Android patch: secure model updates, TLS pinning, anti-tamper, ensemble gating, TFLite wrapper, scanner, leverage policy.
Fill placeholders in code:
- Verifier.PUBKEY_B64
- AntiTamper.EXPECTED_CERT_SHA256
- NetworkModule pin for ${BACKEND_HOST}
- AppConfig.GATEWAY_BASE_URL
