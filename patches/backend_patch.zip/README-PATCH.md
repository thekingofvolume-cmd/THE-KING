Backend patch: FastAPI with klines proxy/cache, indicators, ops/tamper intake, and model approvals.
- Set ADMIN_API_KEY in .env for admin endpoints.
- Start with: uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload
